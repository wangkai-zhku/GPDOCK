###an effective strategy for re-ranking the docking results of GPDOCK (2 water).

zzoutfiture_2.sh:  re-ranking all the docking results which including 2 water molecule.
NOTE: You can run it directly from this file

zzout_fiture_wat_2:   the program can calculate 36 features writen by C program.
     ./zzout_fiture_wat_2 -PRO protein.pdb -LIG ligand.mol2 -DOCK out_wat_2.pdb -TMP temp1.pdb
     the file of 11111.dat will be obtained
 
zzout.py :  the python program that can call machine learning model to get the sequence file.

zdis.pth: The result file of the machine learning model

rerank_result: the program to get the rerank file of docking results.
       the final file of ml_dock.pdb will be obtained.


