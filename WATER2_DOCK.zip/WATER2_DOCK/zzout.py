import os
import pandas as pd
import numpy as np
import torch
import torch.nn.functional as F
import matplotlib.pyplot as plt
import re
from torch.autograd import Variable
xy_use = np.loadtxt('ml_middle.csv',delimiter=',',dtype=np.float32)
x_use = torch.from_numpy(xy_use[:,:])

class Net(torch.nn.Module):
    def __init__(self):
        super(Net, self).__init__()
        self.linear1 = torch.nn.Linear(36,1)

    def forward(self, x):
        x = torch.sigmoid(self.linear1(x))
        return x

class_names = ['1', '0']
model_save_path = 'zdis.pth'
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
x_use = x_use.to(device)
model = torch.load(model_save_path)
model.eval()
out = model(x_use)
pred = torch.tensor([[1] if num[0] >= 0.5 else [0] for num in out]).to(device)
aa = pred.cpu().numpy()
np.set_printoptions(threshold=np.inf)

f = open("11111.dat","w")
print(re.sub('[\[\]]','', np.array_str(aa)), file = f)
f.close
