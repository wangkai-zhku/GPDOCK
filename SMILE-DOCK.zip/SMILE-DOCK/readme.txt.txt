Crystal Structure:
protein: 1a42-pro.pdb
              1atl_pro.pdb

ligand: 1a42-crystal-lig.mol2
            1atl-crystal-lig.mol2

3D models constructed by openbabel based on SMILES of the ligand in 1a42 and 1atl:
            1a42-3d-construct.mol2
            1atl-3d-construct.mol2

energy minimization for these 3D models:
            1a42-low-energy.mol2
            1atl-low-energy.mol2

the docking results docked by GPDOCK based on the crystal structure of ligand. 
            1a42-crystal-out.pdb
            1atl-crystal-out.pdb

the docking results docked by GPDOCK based on energy minimization of ligand constructed by obconformer. 
            1a42-low-energy-out.pdb
            1atl-low-energy-out.pdb

the docking results splited by gp_split of GPDOCK to maintain each outputfile contains one docking results.
           1a42-output-1.pdb
           1a42-output-2.pdb
           .....................................
