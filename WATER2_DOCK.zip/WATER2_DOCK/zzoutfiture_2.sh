for x in *lig_*.mol2
do
y=${x%.mol2}
z=${y/_lig_/_pro_}
echo $y
./zzout_fiture_wat_2 -PRO ${z}.pdb -LIG $x -DOCK ${z}_out_wat_2.pdb -TMP ${z}_temp1.pdb
python zzout.py
./rerank_result -DOCK ${z}_out.pdb -MLD 11111.dat
mv ml_dock.pdb ${z}_rank.pdb
done

